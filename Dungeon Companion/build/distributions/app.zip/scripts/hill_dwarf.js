importPackage(com.schoolerc.fiftheditioncompanion.data);

healthModifierTemplate = {
    apply: function(state){state.setMaxHitPoints(state.getMaxHitPoints()+state.getLevel());}
};

healthModifier = new Modifier(healthModifierTemplate);

subRaceTemplate = {
    getName: function(){return "Hill"},
    getModifiers: function(){return [new AbilityScoreModifier(Wisdom, 1), healthModifier]}
};

race = new Race(raceTemplate);

repository.registerSubRace("Dwarf", race);